package com.goxr3plus.streamplayer.application;

public class Main {
    public static void main(String[] args) {

        final DemoApplication application = new DemoApplication();
        application.start();

    }
}
